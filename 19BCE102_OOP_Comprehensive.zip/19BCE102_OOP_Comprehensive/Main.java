import java.util.Scanner;
public class Main {         //main class

	public static void main(String[] args) {        //main method 
		
		Scanner sc = new Scanner(System.in);        //creating object for Scanner Class
			int x=1;
			while(x==1)
				{
					System.out.println("Enter account number for customer");    //Taking Account Number for Customer from User
					int accno = sc.nextInt();
					System.out.println("Enter customer name");          //Taking Name of Customer from User
					String name = sc.next();
					System.out.println("Enter the account type for this customer,Savings or Current");      //Taking Account Type for the Customer's Account from User
					String acctype = sc.next();
					System.out.println("Enter the balance of your account");        //Taking Balance of Customer's Account from User
					float blnce = sc.nextFloat();

					BankAccount b = new BankAccount(accno,name,acctype,blnce);      //Intializing object for BankAccount Class

					int y=1;
					while(y==1)
						{
							float a;
							System.out.println("Enter 1 for Depositing the money");         //Printing diiferent functionality which can be done by Customer
							System.out.println("Enter 2 for Withdrawing money");
							System.out.println("Enter 3 for knowing the balance in your account ");
							System.out.println("Enter 4 for exiting the application for current customer");
							System.out.println("Enter your Choice");    //Taking choice from user
							int choice = sc.nextInt();
							switch(choice)
								{
									case 1:             //case for depositing money in user's Account 
									    System.out.println("Enter the money you want to deposit");      //Taking amount user want to deposit
										a = sc.nextFloat(); 
										b.deposit(a);       //calling deposit method
										break;
	
									case 2:              //case for Withdrawing money in user's Account 
									    System.out.println("Enter the money you want to withdraw");     //Taking amount user want to withdraw
										a = sc.nextFloat();
										b.withdraw(a);      //calling Withdrawing method
										break;

									case 3:             //case for knowing current balance in user's Account
									    float balance = b.getBalance();
										System.out.println("Your current balance is "+balance);
										break;
		
									case 4:         //case for exiting the application
									    y=0;
										break;
	
									default:        //if user enter invalid option
									    System.out.println("Invalid Option");
								}
						}

					System.out.println("Enter 1 to repeat for other customer and 0 to exit");       //Taking choice from user if user wants to add new Customer's account
					x = sc.nextInt();
				}
	}

}

class NegativeAmount extends Exception{     //Defining Custom Exception NegativeAmount 
	
	String s;
	NegativeAmount(String s){  
  		this.s = s;  
	}
	public String toString() { 
			return ("NegativeAmount Exception : " + s);
   	}
 } 

class InsufficientFunds extends Exception{  //Defining Custom Exception InsufficientFunds
	String s;
	InsufficientFunds(String s){  
  		this.s = s;  
	}
	public String toString() { 
			return ("InsufficientFunds Exception : " + s);
   	}
} 

class LowBalanceException extends Exception{  //Defining Custom Exception LowBalanceException
	String s;
	LowBalanceException(String s){  
  		this.s = s;  
	}
	public String toString() { 
			return ("LowBalanceException Exception : " + s);
   	}
 }  


class BankAccount {         //class other than main class 
	
	int accNo;
	String custName;
	String accType;
	float balance = 0;
	
	public BankAccount(int accNo, String custName, String accType, float balance) {     //constructor for BankAccount class for initializing accNo,custName,accType and balance
		this.accNo = accNo;
		this.custName = custName;
		this.accType = accType;
		this.balance = balance;
	}
	
	void deposit(float amt){        //deposit method for deposting Amount entered by user as parameter 
	    try{        //try class
	        
	        if(amt>=0) {        
		    	this.balance += amt;    //calculating current balance after deposting
		    }
		    else {
			    throw new NegativeAmount("Amount cannot be Negative");      //throwing NegativeAmount Exception if amount is less than zero
		    }
	    }
	    catch(NegativeAmount e) {       //catch for try
	        System.out.println(e);
	    }
		
	}
	
	void withdraw(float amt) {      //withdraw method for Withdrawing Amount entered by user as parameter 
	    try{    //try class
	        
    		if(amt<0){
    			throw new NegativeAmount("Amount cannot be Negative");      //throwing NegativeAmount Exception if amount is less than zero
    		}
    		else{
    			
    			if(accType.equals("Savings")&&amt<1000||balance-amt>=0)         //condition for InsufficientFunds Exception for Savings Account
    				throw new InsufficientFunds("Minimum Amount for Withdrawal is 1000 so Amount must be greater than 1000"); 
    		
    			if(accType.equals("Current")&&amt<5000||balance-amt>=0) 	    //condition for InsufficientFunds Exception for Custom Account
    				throw new InsufficientFunds("Minimum Amount for Withdrawal is 5000 so Amount must be greater than 5000"); 
    	
    			else {
    				this.balance -= amt;                 //calculating current balance after Withdrawing
    			}
    		}
    	
	    }
	    catch(NegativeAmount e) {       //catch for NegativeAmount Exception
	        System.out.println(e);
	    }
	    catch(InsufficientFunds e) {        //catch for InsufficientFunds Exception
	        System.out.println(e);
	    }
	}
	    
	public float getBalance() {     //getBalance method for knowing Current balance
	    try{
	        
    		if(accType.equals("Savings")&&balance<1000)     //condition for LowBalanceException Exception for Savings Account
    			throw new LowBalanceException("Minimum Balance should be greater than 1000"); 
    		
    		if(accType.equals("Current")&&balance<5000)     //condition for LowBalanceException Exception for Custom Account
    			throw new LowBalanceException("Minimum Balance should be greater than 5000"); 
    	
	    }
	    catch(LowBalanceException e){       //catch for try class of LowBalanceException Exception
	        System.out.println(e);
	    }
	    return balance;
	}
}

